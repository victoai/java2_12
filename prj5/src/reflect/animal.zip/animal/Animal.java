package reflect.animal;


public class Animal {
	
	public void bark() {   
		  
	}
}
