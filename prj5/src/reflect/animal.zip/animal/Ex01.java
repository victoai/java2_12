package reflect.animal;

public class Ex01 {

	public static void main(String[] args) {
		 
	//	Cat cat = new Cat();
		Dog dog  = new Dog();
		dog.bark();
				
	}

}
