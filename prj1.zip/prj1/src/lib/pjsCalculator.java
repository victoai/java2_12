package lib;

import prj1.ICalculator;

public class pjsCalculator implements ICalculator{
	public int add(int su1,int su2){
		System.out.println("dap");
		return su1+su2;
	}
}
