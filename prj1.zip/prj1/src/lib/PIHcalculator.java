package lib;

import prj1.ICalculator;

public class PIHcalculator implements ICalculator{

	@Override
	public int add(int su1, int su2) {
		// TODO Auto-generated method stub
		System.out.println("PIH calculator");
		return su1+su2;
	}

}
