package prj1;

import java.util.ArrayList;

public class FoodSortEx {

	public static void main(String[] args) {
		 
		
	 ArrayList<Food> list = new ArrayList<>();
	 
	 list.add(new Food( "크림파스타" , 15000));
	 list.add(new Food( "돌솥비빔밥" , 11000));
	 list.add(new Food( "쫄면" , 7000));
	 
	 // 정렬 
	 
	 
	 
	 

	}

}
