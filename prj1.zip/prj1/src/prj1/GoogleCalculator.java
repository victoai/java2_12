package prj1;


public class GoogleCalculator implements ICalculator {

	@Override
	public int add(int su1, int su2) {
		// TODO Auto-generated method stub
		System.out.println("google");
		return su1+su2;
	}

}
