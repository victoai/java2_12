package prj1;


public class KakaCalculator implements ICalculator {
	@Override
	public int add(int su1, int su2) {
		// TODO Auto-generated method stub
		System.out.println(" kakao");
		return su1+ su2;
	}

	
}
