package prj1;

public interface MyComparator {
	public int compare(Object o1, Object o2);
}
