package prj1;

public class BCalculator {
	
	public int addB( int su1, int su2) {
		return  su1+ su2;
	}
}
