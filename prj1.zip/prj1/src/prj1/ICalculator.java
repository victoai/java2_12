package prj1;


public interface ICalculator {
		public int add( int su1, int su2);
}
