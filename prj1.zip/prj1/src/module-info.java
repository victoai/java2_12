/**
 * 
 */
/**
 * @author user
 *
 */
module prj1 {
}