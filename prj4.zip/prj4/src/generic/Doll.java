package generic;

public class Doll extends Toy {

}
