package generic;

public class Car {

}
