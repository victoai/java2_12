package generic;

public class ToyCar  extends Toy{

}
