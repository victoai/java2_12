package generic;

public class Toy {

}
