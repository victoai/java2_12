package practice.mj;

public interface PMJInterface {

	void stock(String name);
}
