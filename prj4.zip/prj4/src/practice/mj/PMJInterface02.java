package practice.mj;

@FunctionalInterface
public interface PMJInterface02 {

	int salePer(int price, int percent);
}
