package ex;

public class Interface3Imp  implements Interface3{
	@Override
	public int method(int x) {		 
		return  x*x;
	}

}
