package ex;

public interface Interface3 {
	  int method( int x);
}
