package ex;

public interface Interface4 {
	 int  method ();
}
