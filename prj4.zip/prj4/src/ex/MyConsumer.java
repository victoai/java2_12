package ex;

public interface MyConsumer {
   void accept( String str);
}
