package task.박근현_최범준;

public interface Mynumber {
	int getNum();
}
