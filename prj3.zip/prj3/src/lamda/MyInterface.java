package lamda;

public interface MyInterface {
    void print( int x);
}
