package lamda;

public interface MyInterface2 {
	
	void print();

}
