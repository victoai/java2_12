package lamda;


@FunctionalInterface
public interface CalculatorI {
	 int add( int su1,  int su2);	 
}
