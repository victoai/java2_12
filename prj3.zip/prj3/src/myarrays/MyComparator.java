package myarrays;

public interface MyComparator {
	int compare( Object o1, Object o2);

}
