/**
 * 
 */
/**
 * @author user
 *
 */
module prj2 {
	requires java.desktop;	
}