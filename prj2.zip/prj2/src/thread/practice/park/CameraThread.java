package thread.practice.park;

public class CameraThread extends Thread{
	@Override
	public void run() {
		System.out.println("**********찰칵***********");
	}
}
